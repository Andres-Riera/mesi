/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file interval.cc 
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 25 Oct 2023
  * @brief This program reads two numbers a and b and prints all numbers 
  	   between them
  * @bug There are no known bugs
  * @see https://jutge.org/problems/P97156_en/statement
  */

#include <iostream>

int main() {
  int a;
  int b;
  std::cin >> a >> b;
  for (int i = a; i <=b; i++) {
    std::cout << i;
    if (i < b) {
      std::cout << ",";
    }
  }
  std::cout << std::endl;
  return 0;
}
