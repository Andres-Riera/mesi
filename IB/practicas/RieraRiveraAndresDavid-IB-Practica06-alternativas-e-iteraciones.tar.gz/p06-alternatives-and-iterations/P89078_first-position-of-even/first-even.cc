/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file first-even.cc
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 26 Oct 2023
  * @brief This program reads a sequence of natural numbers and prints the 
	   position of the first even number
  * @bug There are no known bugs
  * @see https://jutge.org/problems/P89078_en/statement 
  */

#include <iostream>
#include <vector>

int main() {
  std::vector<int> numbers;
  int value;
  int position {1};
  while (std::cin >> value) {
    numbers.push_back(value);
  }
  for (int i = 0; i < numbers.size(); i++) {
    if (numbers[i] % 2 == 0) {
      std::cout << position << std::endl;
    break;
    }
    position++;
  }  
  
  return 0;
}
