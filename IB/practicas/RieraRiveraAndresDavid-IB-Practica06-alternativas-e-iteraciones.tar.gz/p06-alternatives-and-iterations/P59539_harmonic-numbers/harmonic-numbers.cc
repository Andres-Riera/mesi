/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file harmonic-numbers.cc
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 25 Oct 2023
  * @brief  This program reads a number and prints the n-th harmonic number
  * @bug There are no known bugs
  * @see https://jutge.org/problems/P59539_en/statement 
  */

#include <iostream>
#include <iomanip>

int main() {
  double number;
  std::cin >> number;
  double output {0};
  double i = 1; 
  for (double& copy = output ; i <= number; ++i) {
     copy= copy + 1 / i;
  }
  std::cout << std::fixed;
  std::cout << std::setprecision(4) << output << std::endl;
}
