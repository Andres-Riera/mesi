/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file top-to-bottom.cc 
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 26 Oct 2023
  * @brief This program reads two numbers x and y and prints all the numbers
  	   between the highest and the lowest
  * @bug There are no known bugs
  * @see https://jutge.org/problems/P59875_en
  */

#include <iostream>

void Order(int& x, int& y) {
  if (y > x) {
    int temp = x;
    x = y;
    y = temp;
  }
}

int main() {
  int x;
  int y;
  std::cin >> x >> y;
  Order(x, y);
  for (int i = x; i >= y; i--) {
    std::cout << i << std::endl;
  }
}
