/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file letters.cc 
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 25 Oct 2023
  * @brief This program read letter and prints it in lowercase if it was an
  	   uppercase and vice versa 
  * @bug There are no known bugs
  * @see https://jutge.org/problems/P98960_en/statement 
  */

#include <iostream>

int main() {
  char letter;
  int other_letter;
  std::cin >> letter;
  other_letter = static_cast<int>(letter);
  if (other_letter > 90) {
    other_letter = other_letter - 32;
  }
  else {
    other_letter = other_letter + 32;
  }
  std::cout << static_cast<char>(other_letter) << std::endl;

  return 0;
}
