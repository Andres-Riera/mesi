#include <iostream>

#include "polynomial.h"

int main(int argc, char* argv[]) {
  std::vector<int> numbers;
  for (int i = 1; i < argc - 1; i++) {
    numbers.push_back(std::stoi(argv[i]));
  }
  int value = argc - 1;
  std::cout << Result(numbers, value) << std::endl;
  return 0;
}
