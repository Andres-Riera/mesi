#include <vector>

int Result(std::vector<int> numbers, int value);
