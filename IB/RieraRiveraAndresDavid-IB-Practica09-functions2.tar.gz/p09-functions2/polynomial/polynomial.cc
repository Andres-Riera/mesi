#include <vector>

#include "polynomial.h"

int Result(std::vector<int> numbers, int value) {
  int result {0};
  for (int i = 0; i < numbers.size() - 1; i++) {
    result = result * value + numbers[i];
  }
  return result;
}
