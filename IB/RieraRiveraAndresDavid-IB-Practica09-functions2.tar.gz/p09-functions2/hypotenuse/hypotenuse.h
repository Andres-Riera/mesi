int Hipotenusa(const int cateto1, const int cateto2);
