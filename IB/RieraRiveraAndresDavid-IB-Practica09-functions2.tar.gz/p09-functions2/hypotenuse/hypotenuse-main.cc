#include <iostream>

#include "hypotenuse.h"

int main(int argc, char* argv[]) {
  int cateto1 = std::stoi(argv[1]);
  int cateto2 = std::stoi(argv[2]);
  std::cout << Hipotenusa(cateto1, cateto2) << std::endl;
  return 0;
}
