#include <cmath>

#include "hypotenuse.h"

int Hipotenusa(const int cateto1, const int cateto2) {
  double hipotenusa = sqrt(cateto1 * cateto1 + cateto2 * cateto2);
  return hipotenusa;
}
