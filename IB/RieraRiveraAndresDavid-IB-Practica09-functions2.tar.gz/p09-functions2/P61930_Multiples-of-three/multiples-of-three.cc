/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 16 Nov 2023 
  * @brief This function reads a number aand tells if it is multiple of three
  * @bug There are no known bugs
  */

bool is_multiple_3(int n) {
  if (n % 3 == 0) {
    return true;
  }
  return false;
}
