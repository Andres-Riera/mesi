#include <vector>

double scalar_product(const std::vector<double>& u, const std::vector<double>& v);
