#include <iostream>
#include <vector>

#include "scalar-product.h"

int main () {
  std::vector<double> vector1;
  std::vector<double> vector2;
  for (int i = 0; i < 3; i++) {
    int value;
    std::cin >> value;
    vector1.push_back(value);
  }
  for (int i = 0; i < 3; i++) {
    int value;
    std::cin >> value;
    vector2.push_back(value);
  }
  if (vector1.size() != vector2.size()) {
    std::cout << "Los vectores no tienen el mismo tamaño" << std::endl;
    return 0;
  }
  std::cout << scalar_product(vector1, vector2) << std::endl;
  return 0;
}
