double ApproximateRoot(const int number, const double epsilon = 1.0e-4);
