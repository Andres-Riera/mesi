#include <iostream>
#include <string>

#include "approximate-root.h"

int main(int argc, char* argv[]) {
  double number = std::stod(argv[1]);
  std::cout << ApproximateRoot(number) << std::endl;
  return 0;
}
