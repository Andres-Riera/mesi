#include "approximate-root.h"

double ApproximateRoot(const int number, const double epsilon) {
  double root {1.0};
  double delta {1.0};
  while (number - root * root > epsilon) {
    if (delta > 0) {
      while (root * root < number) {
        root += delta;
      }
    }
    else {
      while (root * root > number) {
        root -= delta;
      }
    }
    delta = delta * -0.5;
  }
  return root;
}
