/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 16 Nov 2023 
  * @brief This function reads a number an tells if the digits in even 
  *    positions is equal to the sum of the digits in odd positions or not
  * @bug There are no known bugs
  */


bool is_balanced(int n) {
  int copy = n;
  int odds {0};
  int evens {0};
  int digits = n / 10 + 1;
  while (copy > 0) {
    if (digits % 2 == 0) {
      odds += copy % 100 - copy % 10;
      copy /= 100;
    }
    else {
      odds += copy % 10; 
      copy /= 10;
    }
  }
  copy = n;
  while (copy > 0) {
    if (digits % 2 == 0) {
      if (copy == n) {
        evens += copy % 10;
        copy /= 10;
      }
      else {
        evens += copy % 100 - copy % 10;
        copy /= 100;
      }
    }
    else {
      evens += copy % 10; 
      copy /= 10;
    } 
  }
  if (odds == evens) {
    return true;
  }
  return false;
}
