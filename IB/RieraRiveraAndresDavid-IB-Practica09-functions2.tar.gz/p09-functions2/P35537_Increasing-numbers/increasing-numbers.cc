/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 16 Nov 2023 
  * @brief This function tells if the digits of a given number are increasing or
  *        not
  * @bug There are no known bugs
  */

#include <iostream>

bool is_increasing(int n){
  int digits = n / 10 + 1;
  for (int i = 0; i < digits; i++) {
    int digit = n % 10;
    if (digit < (n / 10) % 10) {
      return false;
    }
    n /= 10;
  }
  return true;
}
