#include <string>

void CaseConverter(std::string& word);
