#include <iostream>

#include "capitalize-vowels.h"

int main(int argc, char* argv[]) {
  std::string word = argv[1];
  CaseConverter(word);
  std::cout << word << std::endl;
  return 0;
}
