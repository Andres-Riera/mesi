/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file fibonacci.cc 
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 23 Oct 2023
  * @brief This program prints the first Fibonacci terms
  * @bug There are no known bugs
  */

#include <iostream>
#include <vector>

using namespace std;
int main() {
  int number_zero {0};
  int number_one {1};
  int numbers [12] {number_zero, number_one};
  std::cout << number_zero << " " << number_one;
  int j;
  int number_out;
  for (int i = 0; i < 12; i ++){
    number_out = numbers [i] + numbers [i + 1];
    j = 2 + i;
    numbers[j] = number_out;
    std::cout << " " << numbers [j];
  }
  std::cout << std::endl;
  
  return 0;
}
