/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file reloj.cc
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date Oct 23 2023
  * @brief This program request the current hour and an integer number of hours
           and prints what the clock will mark 
  * @bug There are no known bugs
  */

#include <iostream>

int main() {
  int hora_act {};
  int horas {};
  std::cout << "Hora actual: ";
  std::cin >> hora_act;
  std::cout << "Cantidad de horas: ";
  std::cin >> horas;
  int copia_horas = horas;
  while (copia_horas > 24) {
    copia_horas= copia_horas - 24;
  }
  int reloj {hora_act + c};
  while (reloj > 24) {
    reloj = reloj - 24;
  }
  std::cout << "En " << horas << " horas, el reloj marcará las " << reloj << std::endl;
  
    return 0;
}
