/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file potencia.cc
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 23 Oct 2023
  * @brief This program reads an integer number and prints the powers of 2 from 0
           to the number put
  * @bug There are no known bugs 
  */

#include <iostream>
#include <cmath>

int main() {
  int number {};
  std::cout << "Introduzca un número: ";
  std::cin >>number;
  for (int i = 0; i <= number; i++) {
    std::cout << pow(2, i) << " ";
  }
  std::cout << std::endl;

  return 0;
}
