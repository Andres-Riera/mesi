/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file divisores.cc 
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 23 Oct 2023
  * @brief This program reads an integer number and prints all its divisors
  * @bug There are no known bugs
  */

#include <iostream>

int main() {
  int number {};
  std::cout << "Introduzca un número: ";
  std::cin >>number;
  for (int i = 1; i <= number; i++) {
    if (number % i == 0) {
      std::cout << i << " ";
    }
  }
  std::cout << std::endl;
  return 0;
}
