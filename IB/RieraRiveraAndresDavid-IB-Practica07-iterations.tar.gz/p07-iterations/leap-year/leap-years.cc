/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 29 Oct 2023
  * @brief This program reads a year and prints if it is a leap year
           or not
  * @bug There are no known bugs
  */

#include <iostream>

void PrintProgramPurpose() {
  std::cout << "This program reads a year over 1800 and tells if it is or is not a leap year" << std::endl;
  std::cout << "Introduce a year: ";
}

bool CheckCorrectParameter(int year) {
  if (year >= 1800) {
    return true;
  }
  else {
    return false;
  }
}

int main() {
  PrintProgramPurpose();
  int year;
  std::cin >> year;
  while (!CheckCorrectParameter(year)) {
    std::cout << "Wrong input" << std::endl;
    std::cout << "Input has to be 1800 or higher" << std::endl;
    std::cout << "Introduce a year: ";
    std::cin >> year;
  }
  if ((year % 4 != 0 || year % 100 == 0) && year % 400 != 0) {
    std::cout << "NO" << std::endl;
  }
  else {
    std::cout << "YES" << std::endl;
  }
  
  return 0;
}
