/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 02 Nov 2023 
  * @brief This program reads a chess board of n rows and n columns and prints
           the total number of coins on its two diagonals.
  * @bug There are no known bugs
  */

#include <iostream>
#include <string>

int main() {
  int n;
  std::cin >> n;
  int coins {0};
  int j = n - 1;
  for (int i = 0; i < n; i++) {
    std::string number;
    std::cin >> number;
    if (i != j) {
      coins += static_cast<int>(number[i] - 48) + static_cast<int>(number[j] - 48);
    }
    else {
      coins += static_cast<int>(number[i] - 48);
    }
    j--;
  }
  std::cout << coins << std::endl;

  return 0;
}
