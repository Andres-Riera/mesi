/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 29 Oct 2023
  * @brief This program reads a decimal number and prints it in binary
  * @bug There are no known bugs
  */

#include <iostream>

void PrintProgramPurpose() {
  std::cout << "This program reads a decimal number and prints it in binary" << std::endl;
  std::cout << "Introduce a number: ";
}

int main() {
  void PrintProgramPurpose();
  int decimal;
  std::cin >> decimal;
  int binary {0};
  int j = 1;
  while (decimal >= 1) {
    binary = binary + decimal % 2 * j;
    decimal /= 2;
    j *= 10;
  }
  std::cout << binary << std::endl;
  
  return 0;
}
