/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 29 Oct 2023
  * @brief This program reads an integer number and prints the sum of its digits
  * @bug There are no known bugs
  */

#include <iostream>
#include <vector>

void PrintProgramPurpose() {
  std::cout << "This program reads an integer number and prints the sum of its digits" << std::endl;
  std::cout << "Press ctrl + d to end the execution" << std::endl;
}

int main() {
  PrintProgramPurpose();
  int number;
  while(std::cin >> number) {
    int copy = number;
    std::vector<int> sum;
    while (number >= 1) {
      int digit = number % 10;
      number /= 10;
      sum.push_back(digit);
    }
    int result {0};
    for (int i = 0; i < sum.size(); i++) {
      result += sum[i];
    }
    std::cout << "The sum of the digits of " << copy << " is " << result << "." << std::endl;
  }
  
  return 0;
}
