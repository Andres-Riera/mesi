/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 29 Oct 2023
  * @brief This program reads a binary number and prints it in decimal
  * @bug There are no known bugs
  */

#include <iostream>

void PrintProgramPurpose() {
  std::cout << "This program reads a binary number and prints it in decimal" 
	    << std::endl;
  std::cout << "Introduce a binary number: ";
}

bool CheckCorrectParameter(int binary) {
  while (binary >= 1) {
    if (binary % 10 > 1) {
      return false;
    }
    binary /= 10;
  }
  return true;
}

int main() {
  PrintProgramPurpose();
  int binary;
  std::cin >> binary;
  while (!CheckCorrectParameter(binary)) {
    std::cout << "Wrong Input" << std::endl;
    std::cout << "The input has to be a binary number" << std::endl;
    std::cout << "Introduce a binary number: ";
    std::cin >> binary;
  }
  int copy = binary;
  int digits {0};
  while (copy >= 1) {
    copy /= 10;
    digits += 1;
  }
  int decimal {0};
  int j = 1;
  for (int i = 1; j <= digits; i = i * 2) {
    decimal = decimal + (binary % 10) * i;
    binary /= 10;
    j++;
  }
  std::cout << decimal << std::endl;

  return 0;
}
