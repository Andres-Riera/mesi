/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @author Andrés David Riera Rivera alu0101618654@ull.edu.es
  * @date 02 Nov 2023 
  * @brief This program reads a natural n and writes n×n figures
  * @bug There are no known bugs
  * @see https://jutge.org/problems/P32533_ca/statement 
  */

#include <iostream>

int main() {
  int number;
  std::cin >> number;
  for (int i = number; i > 0; i--) {
    for (int j = 1; j < i; j++) {
      std::cout << "+";
    }
      std::cout << "/";
      if (i != number) {
        for (int j = number; j > i; j--) {
          std::cout << "*";
        }
      }
      std::cout << std::endl;
  }
  return 0;
}
