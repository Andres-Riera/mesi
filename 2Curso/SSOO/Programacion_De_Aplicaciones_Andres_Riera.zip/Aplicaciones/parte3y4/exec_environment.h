#pragma once

#include <sys/socket.h> 
#include <netinet/ip.h>
#include <sys/un.h> 
#include <arpa/inet.h> 
#include <unistd.h> 
#include <string.h>
#include <cstdlib>
#include <sstream>

/*
El programa docserver configurará una serie de variables de entorno con información para
que el programa que se ejecute pueda saber más sobre la petición que se le ha hecho y el
entorno en el que se está ejecutando:
• REQUEST_PATH: La ruta del archivo que el cliente indicó en la petición, que será la ruta
del programa que se está ejecutando.
• SERVER_BASEDIR: La del directorio base que está usando docserver.
• REMOTE_PORT: El puerto desde el que se ha hecho la petición.
• REMOTE_IP: La dirección IP del cliente que ha hecho la petición.

*/

class exec_environment { // Ahora mismo no funciona la clase
 public:
  exec_environment(std::string path, std::string base_dir, uint16_t port, uint32_t ip)
      : path_(path), base_dir_(base_dir), port_(port), ip_(ip) {
    std::string port_str = std::to_string(port_);
    std::string ip_str = std::to_string(ip_);
    /*setenv("REQUEST_PATH", path_.c_str(), 1);
    setenv("SERVER_BASEDIR", base_dir_.c_str(), 1);
    setenv("REMOTE_PORT", port_str.c_str(), 1);
    setenv("REMOTE_IP", ip_str.c_str(), 1);*/
    env_[0] = ("REQUEST_PATH=" + path_).c_str();
    env_[1] = ("SERVER_BASEDIR=" + base_dir_).c_str();
    env_[2] = ("REMOTE_PORT=" + port_str).c_str();
    env_[3] = ("REMOTE_IP=" + ip_str).c_str();
    env_[4] = nullptr;
  }

  std::string get_path() { return path_; }
  std::string get_base_dir() { return base_dir_; }
  uint16_t get_port() { return port_; }
  uint32_t get_ip() { return ip_; }

  const char* const* get() const { return env_; }
  
 private:
  std::string path_;
  std::string base_dir_;
  uint16_t port_;
  uint32_t ip_;
  const char* env_[5];
};